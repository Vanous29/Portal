// Coin System - Vylepšená verze s购买 mechanikou
(function() {
  const CoinSystem = {
    init() {
      this.loadCoins();
      this.loadPurchases();
      this.updateDisplay();
    },

    loadCoins() {
      const games = ['snake', '2048', 'tetris', 'breakout', 'flappy', 'pong'];
      this.totalCoins = parseInt(localStorage.getItem('totalCoins')) || 0;
      
      games.forEach(game => {
        const coins = parseInt(localStorage.getItem(`${game}Coins`)) || 0;
        const highscore = parseInt(localStorage.getItem(`${game}HighScore`)) || 0;
        
        this[`${game}Coins`] = coins;
        this[`${game}HighScore`] = highscore;
      });
    },

    loadPurchases() {
      this.purchases = JSON.parse(localStorage.getItem('purchases')) || {};
    },

    savePurchases() {
      localStorage.setItem('purchases', JSON.stringify(this.purchases));
    },

    purchaseGame(gameId, cost) {
      if (this.totalCoins >= cost && !this.purchases[gameId]) {
        this.totalCoins -= cost;
        localStorage.setItem('totalCoins', this.totalCoins);
        this.purchases[gameId] = true;
        this.savePurchases();
        this.updateDisplay();
        return true;
      }
      return false;
    },

    isPurchased(gameId) {
      return this.purchases[gameId] === true;
    },

    addCoins(amount, game = null) {
      this.totalCoins += amount;
      localStorage.setItem('totalCoins', this.totalCoins);
      
      if (game) {
        const key = `${game}Coins`;
        this[key] = (this[key] || 0) + amount;
        localStorage.setItem(key, this[key]);
      }
      
      this.updateDisplay();
      this.showCoinAnimation(amount);
    },

    updateDisplay() {
      const totalCoinsEl = document.getElementById('total-coins');
      if (totalCoinsEl) {
        totalCoinsEl.textContent = this.totalCoins;
      }

      const games = ['snake', '2048', 'tetris', 'breakout', 'flappy', 'pong'];
      games.forEach(game => {
        const coinsEl = document.getElementById(`${game}-coins`);
        const highscoreEl = document.getElementById(`${game}-highscore`);
        
        if (coinsEl) coinsEl.textContent = this[`${game}Coins`] || 0;
        if (highscoreEl) highscoreEl.textContent = this[`${game}HighScore`] || 0;
      });
    },

    showCoinAnimation(amount) {
      const coinDisplay = document.querySelector('.coin-display');
      if (!coinDisplay) return;

      const animation = document.createElement('div');
      animation.className = 'coin-popup';
      animation.textContent = `+${amount} 🪙`;
      animation.style.cssText = `
        position: absolute;
        top: -30px;
        left: 50%;
        transform: translateX(-50%);
        color: #ffd700;
        font-weight: bold;
        font-size: 1.2rem;
        animation: coinFloat 1s ease-out forwards;
        pointer-events: none;
        text-shadow: 0 0 10px rgba(255, 215, 0, 0.8);
      `;

      const style = document.createElement('style');
      if (!document.getElementById('coin-animation-style')) {
        style.id = 'coin-animation-style';
        style.textContent = `
          @keyframes coinFloat {
            0% { opacity: 1; transform: translateX(-50%) translateY(0); }
            100% { opacity: 0; transform: translateX(-50%) translateY(-50px); }
          }
        `;
        document.head.appendChild(style);
      }

      coinDisplay.style.position = 'relative';
      coinDisplay.appendChild(animation);
      setTimeout(() => animation.remove(), 1000);
    }
  };

  CoinSystem.init();
  window.CoinSystem = CoinSystem;
})();